// ...existing code...
const UserModel = require('../Models/user');
const bcrypt = require('bcrypt');

/**
 * UserController - function based (Express handlers)
 * Uses UserModel for user-only fields and handles hashing/auth where appropriate.
 */
const UserController = {
  list: function (req, res) {
    UserModel.getAll((err, users) => {
      if (err) {
        console.error('Error fetching users:', err);
        return res.status(500).send('Internal Server Error');
      }
      res.render('users', { users });
    });
  },

  getById: function (req, res) {
    const id = req.params.id;
    UserModel.getById(id, (err, user) => {
      if (err) {
        console.error(`Error fetching user ${id}:`, err);
        return res.status(500).send('Internal Server Error');
      }
      if (!user) return res.status(404).send('User not found');
      res.render('profile', { user });
    });
  },

  registerForm: function (req, res) {
    res.render('register');
  },

  register: function (req, res) {
    const userData = {
      userName: req.body.userName || req.body.name || null,
      email: req.body.email || null,
      password: req.body.password || null,
      address: req.body.address || null,
      contact: req.body.contact || null,
      role: req.body.role || 'customer'
    };

    if (userData.password) {
      bcrypt.hash(userData.password, 10, (hashErr, hash) => {
        if (hashErr) {
          console.error('Error hashing password:', hashErr);
          return res.status(500).send('Internal Server Error');
        }
        userData.password = hash;
        UserModel.create(userData, (err) => {
          if (err) {
            console.error('Error creating user:', err);
            return res.status(500).send('Internal Server Error');
          }
          res.redirect('/login');
        });
      });
    } else {
      UserModel.create(userData, (err) => {
        if (err) {
          console.error('Error creating user:', err);
          return res.status(500).send('Internal Server Error');
        }
        res.redirect('/login');
      });
    }
  },

  loginForm: function (req, res) {
    res.render('login');
  },

  login: function (req, res) {
    const email = req.body.email;
    const password = req.body.password;

    UserModel.getByEmail(email, (err, user) => {
      if (err) {
        console.error('Error fetching user by email:', err);
        return res.status(500).send('Internal Server Error');
      }
      if (!user) return res.status(401).send('Invalid credentials');

      bcrypt.compare(password, user.password, (cmpErr, match) => {
        if (cmpErr) {
          console.error('Error comparing password:', cmpErr);
          return res.status(500).send('Internal Server Error');
        }
        if (!match) return res.status(401).send('Invalid credentials');
        // session logic would go here
        res.redirect('/');
      });
    });
  },

  update: function (req, res) {
    const id = req.params.id;
    const userData = {
      userName: req.body.userName,
      email: req.body.email,
      password: req.body.password,
      address: req.body.address,
      contact: req.body.contact,
      role: req.body.role
    };

    if (userData.password) {
      bcrypt.hash(userData.password, 10, (hErr, hash) => {
        if (hErr) {
          console.error('Error hashing password:', hErr);
          return res.status(500).send('Internal Server Error');
        }
        userData.password = hash;
        UserModel.update(id, userData, (err, result) => {
          if (err) {
            console.error(`Error updating user ${id}:`, err);
            return res.status(500).send('Internal Server Error');
          }
          if (result && result.affectedRows === 0) return res.status(404).send('User not found');
          res.redirect('/');
        });
      });
    } else {
      UserModel.update(id, userData, (err, result) => {
        if (err) {
          console.error(`Error updating user ${id}:`, err);
          return res.status(500).send('Internal Server Error');
        }
        if (result && result.affectedRows === 0) return res.status(404).send('User not found');
        res.redirect('/');
      });
    }
  },

  delete: function (req, res) {
    const id = req.params.id;
    UserModel.delete(id, (err, result) => {
      if (err) {
        console.error(`Error deleting user ${id}:`, err);
        return res.status(500).send('Internal Server Error');
      }
      if (result && result.affectedRows === 0) return res.status(404).send('User not found');
      res.redirect('/');
    });
  }
};

module.exports = UserController;
// ...existing code...