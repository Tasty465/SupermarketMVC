const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');
const path = require('path');
const app = express();

// MVC imports
const ProductController = require('./Controllers/productcontroller');
const UserController = require('./Controllers/usercontroller');
const ProductModel = require('./Models/product');
const UserModel = require('./Models/user');

// Multer setup for uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'public', 'images')),
  filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage });

// View engine & middleware
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false }));

app.use(session({
  secret: 'secret',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use(flash());

// NEW: rewrite redirects for admin users so controller redirects to '/' go to '/inventory'
app.use((req, res, next) => {
  const originalRedirect = res.redirect.bind(res);
  res.redirect = function (url) {
    // if admin and redirect target is home, send to inventory instead
    if ((url === '/' || url === '') && req.session && req.session.user && req.session.user.role === 'admin') {
      return originalRedirect('/inventory');
    }
    return originalRedirect(url);
  };
  next();
});

// Auth middlewares
const checkAuthenticated = (req, res, next) => {
  if (req.session.user) return next();
  req.flash('error', 'Please log in to view this resource');
  res.redirect('/login');
};

const checkAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') return next();
  req.flash('error', 'Access denied');
  res.redirect('/shopping');
};

// Routes now use controllers / models (no direct SQL or mysql connection here)

// Home - product listing (controller renders view)
app.get('/', ProductController.list);

// Inventory (admin) - use model to render admin inventory view
app.get('/inventory', checkAuthenticated, checkAdmin, (req, res) => {
  ProductModel.getAll((err, products) => {
    if (err) {
      console.error('Error fetching products for inventory:', err);
      return res.status(500).send('Internal Server Error');
    }
    res.render('inventory', { products, user: req.session.user });
  });
});

// Registration & Login (delegated to user controller)
app.get('/register', UserController.registerForm);
app.post('/register', UserController.register);

app.get('/login', UserController.loginForm);
app.post('/login', UserController.login);

// Shopping view - list products for shoppers (uses model)
app.get('/shopping', checkAuthenticated, (req, res) => {
  ProductModel.getAll((err, products) => {
    if (err) {
      console.error('Error fetching products for shopping:', err);
      return res.status(500).send('Internal Server Error');
    }
    res.render('shopping', { products, user: req.session.user });
  });
});

// Cart operations (uses ProductModel to fetch product data)
app.post('/add-to-cart/:id', checkAuthenticated, (req, res) => {
  const productId = parseInt(req.params.id, 10);
  const qty = parseInt(req.body.quantity, 10) || 1;

  ProductModel.getById(productId, (err, product) => {
    if (err) {
      console.error('Error fetching product for cart:', err);
      return res.status(500).send('Internal Server Error');
    }
    if (!product) return res.status(404).send('Product not found');

    if (!req.session.cart) req.session.cart = [];

    // find existing by cart item's id property (canonical)
    const existing = req.session.cart.find(i => i.id === productId);
    if (existing) {
      existing.quantity += qty;
    } else {
      req.session.cart.push({
        id: product.id,                // was product.productId
        productName: product.productName,
        price: product.price,
        quantity: qty,
        image: product.image
      });
    }

    res.redirect('/cart');
  });
});

app.get('/cart', checkAuthenticated, (req, res) => {
  const cart = req.session.cart || [];
  res.render('cart', { cart, user: req.session.user });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// Product detail (controller will render product view; make public so visitors can view product details)
app.get('/product/:id', ProductController.getById);

// Add product (admin)
app.get('/addProduct', checkAuthenticated, checkAdmin, (req, res) => {
  res.render('addProduct', { user: req.session.user });
});
app.post('/addProduct', checkAuthenticated, checkAdmin, upload.single('image'), ProductController.add);

// Update product (admin) - render form via model, update via controller
app.get('/updateProduct/:id', checkAuthenticated, checkAdmin, (req, res) => {
  const productId = req.params.id;
  ProductModel.getById(productId, (err, product) => {
    if (err) {
      console.error('Error fetching product for update:', err);
      return res.status(500).send('Internal Server Error');
    }
    if (!product) return res.status(404).send('Product not found');
    res.render('updateProduct', { product, user: req.session.user });
  });
});
app.post('/updateProduct/:id', checkAuthenticated, checkAdmin, upload.single('image'), ProductController.update);

// Delete product (admin)
app.get('/deleteProduct/:id', checkAuthenticated, checkAdmin, ProductController.delete);

// User profile / admin user management routes (example mappings)
app.get('/users', checkAuthenticated, checkAdmin, UserController.list);
app.get('/user/:id', checkAuthenticated, UserController.getById);
app.post('/user/:id/update', checkAuthenticated, UserController.update);
app.get('/user/:id/delete', checkAuthenticated, checkAdmin, UserController.delete);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
