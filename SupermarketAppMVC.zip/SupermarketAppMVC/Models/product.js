const db = require('../db');

const ProductModel = {
  getAll: function(callback) {
    const sql = 'SELECT id, productName, quantity, price, image FROM products';
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      callback(null, results);
    });
  },

  getById: function(productId, callback) {
    const sql = 'SELECT id, productName, quantity, price, image FROM products WHERE productId = ?';
    db.query(sql, [productId], (err, results) => {
      if (err) return callback(err);
      callback(null, results[0] || null);
    });
  },

  create: function(productData, callback) {
    const sql = 'INSERT INTO products (productName, quantity, price, image, userId) VALUES (?, ?, ?, ?, ?)';
    const params = [productData.productName, productData.quantity || 0, productData.price || 0, productData.image || null, productData.userId || null];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      callback(null, { insertId: result.insertId, ...productData });
    });
  },

  update: function(productId, productData, callback) {
    const sql = 'UPDATE products SET productName = ?, quantity = ?, price = ?, image = ?, userId = ? WHERE productId = ?';
    const params = [productData.productName, productData.quantity, productData.price, productData.image, productData.userId || null, productId];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  },

  delete: function(productId, callback) {
    const sql = 'DELETE FROM products WHERE productId = ?';
    db.query(sql, [productId], (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  },

  updateQuantity: function(productId, quantity, callback) {
    const sql = 'UPDATE products SET quantity = ? WHERE productId = ?';
    db.query(sql, [quantity, productId], (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  }
};

module.exports = ProductModel;