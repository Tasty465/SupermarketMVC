const db = require('../db');

const UserModel = {
  getAll: function(callback) {
    const sql = 'SELECT userId, userName, email, address, contact, role FROM users';
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      callback(null, results);
    });
  },

  getById: function(userId, callback) {
    const sql = 'SELECT userId, userName, email, address, contact, role FROM users WHERE userId = ?';
    db.query(sql, [userId], (err, results) => {
      if (err) return callback(err);
      callback(null, results[0] || null);
    });
  },

  create: function(userData, callback) {
    const sql = 'INSERT INTO users (userName, email, password, address, contact, role) VALUES (?, ?, ?, ?, ?, ?)';
    const params = [userData.userName, userData.email, userData.password, userData.address || null, userData.contact || null, userData.role || 'customer'];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      callback(null, { insertId: result.insertId, ...userData });
    });
  },

  update: function(userId, userData, callback) {
    const sql = 'UPDATE users SET userName = ?, email = ?, password = ?, address = ?, contact = ?, role = ? WHERE userId = ?';
    const params = [userData.userName, userData.email, userData.password, userData.address, userData.contact, userData.role, userId];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  },

  delete: function(userId, callback) {
    const sql = 'DELETE FROM users WHERE userId = ?';
    db.query(sql, [userId], (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  },

  getByEmail: function(email, callback) {
    const sql = 'SELECT userId, userName, email, password, role FROM users WHERE email = ?';
    db.query(sql, [email], (err, results) => {
      if (err) return callback(err);
      callback(null, results[0] || null);
    });
  }
};

module.exports = UserModel;